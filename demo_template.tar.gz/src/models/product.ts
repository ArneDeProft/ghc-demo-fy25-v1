export interface Product {
  productId: number;
  supplierId: number;
}
