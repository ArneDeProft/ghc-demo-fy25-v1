export interface Branch {
  branchId: number;
}
